import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():
    return LaunchDescription([
        # micro-ROS agent node (using serial transport)
        ExecuteProcess(
            cmd=['ros2', 'run', 'micro_ros_agent', 'micro_ros_agent', 'serial', '--dev', '/dev/ttyS0'],
            output='screen'
        ),
        # Joystick driver node (PS4 controller)
        Node(
            package='joy',
            executable='joy_node',
            name='joy_node',
            output='screen',
            parameters=[{
                'dev': '/dev/input/js0',  # Make sure this points to your PS4 device
                'deadzone': 0.05,
                'autorepeat_rate': 20.0,
                'coalesce_interval': 0.001
            }]
        ),
        # Teleop twist joy node
        Node(
            package='teleop_twist_joy',
            executable='teleop_node',
            name='teleop_twist_joy_node',
            output='screen',
            parameters=['/home/pi/mowbot/install/mowbot/share/mowbot/config/ps4.config.yaml']
        )
    ])
