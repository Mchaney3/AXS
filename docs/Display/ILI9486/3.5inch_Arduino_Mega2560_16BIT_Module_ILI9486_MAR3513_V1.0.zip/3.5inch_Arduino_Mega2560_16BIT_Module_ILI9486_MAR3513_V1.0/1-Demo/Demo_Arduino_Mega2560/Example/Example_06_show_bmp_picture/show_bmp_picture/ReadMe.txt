ReadMe:
"show_bmp_picture"example need to read BMP files from SDcard.
so, firstly,you should format your SD-card into fat16 or fat32.
then copy the 01.bmp,02.bmp,03.bmp,04.bmp which are in the PIC folder into your SD-card.

Attention:
This Example only support the Arduino Mega2560 board,not support the UNO,Because they use different SPI bus.